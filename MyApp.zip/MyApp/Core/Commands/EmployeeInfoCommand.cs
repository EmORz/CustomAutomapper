﻿using MyApp.Core.Commands.Interface;

namespace MyApp.Core.Commands
{
    public class EmployeeInfoCommand : ICommand
    {
        public string Execute(string[] inputArgs)
        {
            throw new System.NotImplementedException();
        }
    }
}